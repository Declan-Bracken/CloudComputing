SELECT 	COUNT(occupation)
FROM EmploymentStatistics
WHERE minor_category = 'Business and Financial Operations';