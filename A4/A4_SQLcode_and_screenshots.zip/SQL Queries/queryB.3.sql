SELECT 	*
FROM EmploymentStatistics
WHERE occupation = 'bus drivers';