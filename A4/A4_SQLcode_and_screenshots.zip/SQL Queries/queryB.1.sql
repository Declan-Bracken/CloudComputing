SELECT occupation
FROM EmploymentStatistics
WHERE major_category = 'Computer, Engineering, and Science'
AND year = '2013';